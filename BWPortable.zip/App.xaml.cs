﻿
using System;

using Xamarin.Forms;
using GalaSoft.MvvmLight.Ioc;
using GalaSoft.MvvmLight.Views;

using Com.ITCInfotech.Brainwave.Common;
using Com.ITCInfotech.Brainwave.ViewModels;
using Com.ITCInfotech.Brainwave.Model.Common;
using Com.ITCInfotech.Brainwave.Views;
using Plugin.Connectivity;

namespace Com.ITCInfotech.Brainwave
{
    public partial class App : Application
    {
        public static HomeMasterDetailPage HomeMasterDetail { get; internal set; }
        public static DialogService dialogService;
        public static NavigationService navigationService;

        public App()
        {
            try
            {
                InitializeComponent();

                dialogService = new DialogService();
                navigationService = new NavigationService();

                navigationService.Configure(nameof(PageNames.Login), typeof(LoginPage));
                navigationService.Configure(nameof(PageNames.Home), typeof(HomePage));
                navigationService.Configure(nameof(PageNames.LeaderBoard), typeof(LeaderboardPage));
                navigationService.Configure(nameof(PageNames.Dashboard), typeof(DashboardPage));
                navigationService.Configure(nameof(PageNames.IdeaSubmission), typeof(IdeaSubmissionPage));
                navigationService.Configure(nameof(PageNames.CampaignIdeas), typeof(CampaignIdeasPage));
                navigationService.Configure(nameof(PageNames.CampaignDetails), typeof(CampaignIdeaDetails));

                if (!SimpleIoc.Default.IsRegistered<IDialogService>())
                    SimpleIoc.Default.Register<IDialogService>(() => dialogService);
                if (!SimpleIoc.Default.IsRegistered<INavigationService>())
                    SimpleIoc.Default.Register<INavigationService>(() => navigationService);

                MainPage = new LoginPage();
            }
            catch (Exception ex)
            {
                GlobalVariables.UIException = ex;
            }
        }

        protected override void OnStart()
        {
            // Handle when your app starts
            CrossConnectivity.Current.ConnectivityChanged += OnConnectivityChanged;

        }

        protected override void OnSleep()
        {
            CrossConnectivity.Current.ConnectivityChanged -= OnConnectivityChanged;
            _locator = null;
        }

        protected override void OnResume()
        {
            CrossConnectivity.Current.ConnectivityChanged += OnConnectivityChanged;
            // Handle when your app resumes
        }

        private static ViewModelLocator _locator;
        public static ViewModelLocator Locator
        {
            get => _locator ?? (_locator = new ViewModelLocator());
        }

        /// <summary>
        /// Handle Connectivity Changes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnConnectivityChanged(object sender, Plugin.Connectivity.Abstractions.ConnectivityChangedEventArgs e)
        {
            try
            {
                if (e.IsConnected == false)
                {
                    GlobalUtil.Current.ShowToastMessage(GlobalVariables.ConnectivityMessage, 2);
                }
            }
            catch (Exception ex)
            {
                GlobalVariables.UIException = ex;
            }
        }

        public static bool IsConnectivityAvailable()
        {
            using (var connectivity = CrossConnectivity.Current)
            {
                return connectivity.IsConnected;
            }
        }

    }
}
